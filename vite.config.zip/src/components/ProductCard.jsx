import { Link } from "react-router-dom";
import { useWishlist } from "../context/WishlistContext";

function ProductCard({ product }) {
  const { addToWishlist } = useWishlist();

  return (
    <div style={{
      border: "1px solid #ddd",
      padding: "1rem",
      borderRadius: "8px",
      maxWidth: "250px",
      textAlign: "center",
      boxShadow: "0 2px 5px rgba(0,0,0,0.1)"
    }}>
      <Link to={`/products/${product.id}`} style={{ textDecoration: "none", color: "black" }}>
        <img src={product.image} alt={product.title} style={{ height: "150px", objectFit: "contain" }} />
        <h3 style={{ fontSize: "1rem", margin: "0.5rem 0" }}>{product.title}</h3>
      </Link>
      <p><strong>${product.price}</strong></p>
      <button onClick={() => addToWishlist(product)} style={{
        padding: "0.5rem 1rem",
        backgroundColor: "#f472b6",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
        color: "white",
        marginTop: "0.5rem"
      }}>
        💖 Tambahkan ke Wishlist
      </button>
    </div>
  );
}

export default ProductCard;
