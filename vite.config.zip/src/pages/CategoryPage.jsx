import { useParams, Link } from "react-router-dom";
import useFetch from "../hooks/useFetch";

function CategoryPage() {
  const { category } = useParams();
  const {
    data: items,
    loading,
    error,
  } = useFetch(`https://fakestoreapi.com/products/category/${category}`);

  if (loading) return <p>Loading kategori...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h1>Kategori: {category}</h1>
      {items?.length === 0 ? (
        <p>Tidak ada produk dalam kategori ini.</p>
      ) : (
        <ul>
          {items?.map((item) => (
            <li key={item.id}>
              <Link to={`/products/${item.id}`}>{item.title}</Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default CategoryPage;
