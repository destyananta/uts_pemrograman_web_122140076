import { useWishlist } from "../context/WishlistContext";
import { Link } from "react-router-dom";

function WishlistPage() {
  const { wishlist, removeFromWishlist } = useWishlist();

  return (
    <div>
      <h1>Wishlist Saya</h1>
      {wishlist.length === 0 ? (
        <p>💔 Belum ada produk di wishlist.</p>
      ) : (
        <ul>
          {wishlist.map((item) => (
            <li key={item.id} style={{ marginBottom: "1rem" }}>
              <Link to={`/products/${item.id}`}>
                <strong>{item.title}</strong>
              </Link>
              <br />
              <span>${item.price}</span>
              <br />
              <button onClick={() => removeFromWishlist(item.id)}>
                🗑️ Hapus dari Wishlist
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default WishlistPage;
