import { useRef, useState, useCallback, useEffect } from "react";
import { Link } from "react-router-dom";
import useFetch from "../hooks/useFetch";


function HomePage() {
  const { data: products, loading, error } = useFetch("https://fakestoreapi.com/products");
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState("");

  const searchRef = useRef();

  // Saat data sudah didapat, inisialisasi filtered
  useEffect(() => {
    if (products) {
      setFiltered(products);
      searchRef.current?.focus();
    }
  }, [products]);

  const handleSearch = useCallback((e) => {
    const keyword = e.target.value.toLowerCase();
    setSearch(keyword);
    const result = products?.filter((p) =>
      p.title.toLowerCase().includes(keyword)
    );
    setFiltered(result);
  }, [products]);

  if (loading) return <p>Loading produk...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h1>Daftar Produk</h1>

      <input
        type="text"
        ref={searchRef}
        placeholder="Cari produk..."
        value={search}
        onChange={handleSearch}
        style={{ padding: "0.5rem", marginBottom: "1rem", width: "100%" }}
      />

      {filtered.length === 0 ? (
        <p>Tidak ada produk yang cocok.</p>
      ) : (
        <ul>
          {filtered.map((product) => (
            <li key={product.id}>
              <Link to={`/products/${product.id}`}>
                {product.title}
              </Link>
            </li>
          ))}
        </ul>
      )}

      <h2>Kategori</h2>
      <ul>
        <li><Link to="/kategori/electronics">Electronics</Link></li>
        <li><Link to="/kategori/jewelery">Jewelery</Link></li>
        <li><Link to="/kategori/men's clothing">Men's clothing</Link></li>
        <li><Link to="/kategori/women's clothing">Women's clothing</Link></li>
      </ul>
    </div>
  );
}

export default HomePage;
